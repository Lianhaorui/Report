-- 测试用户数据SQL文件
-- 导入10个测试用户，用户名格式为test1-test10

INSERT INTO `users` (`name`, `email`, `password`, `gender`, `mobile`, `designation`, `image`, `status`) VALUES
('Test User 1', 'test1@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Male', '12345678901', 'Developer', 'default.png', 1),
('Test User 2', 'test2@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Female', '12345678902', 'Designer', 'default.png', 1),
('Test User 3', 'test3@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Male', '12345678903', 'Manager', 'default.png', 1),
('Test User 4', 'test4@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Female', '12345678904', 'Developer', 'default.png', 1),
('Test User 5', 'test5@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Male', '12345678905', 'Tester', 'default.png', 1),
('Test User 6', 'test6@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Female', '12345678906', 'Designer', 'default.png', 1),
('Test User 7', 'test7@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Male', '12345678907', 'Developer', 'default.png', 1),
('Test User 8', 'test8@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Female', '12345678908', 'Manager', 'default.png', 1),
('Test User 9', 'test9@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Male', '12345678909', 'Tester', 'default.png', 1),
('Test User 10', 'test10@example.com', '33175f3f1b4c22ab8c9025e6ce115f77', 'Female', '12345678910', 'Developer', 'default.png', 1);